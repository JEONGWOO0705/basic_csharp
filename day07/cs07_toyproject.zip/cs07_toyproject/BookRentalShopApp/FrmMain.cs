using Ax.Fw.MetroFramework.Forms;

namespace BookRentalShopApp
{
    public partial class FrmMain : BorderlessForm // MetroForm
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            
        }
    }
}
